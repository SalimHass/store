import React, {Component} from 'react';

import './App.css';
import {Query} from "@apollo/client/react/components";
import {GET_PRODUCTS_CATEGORY, GET_CATEGORY_Currency_LIST} from "./GraphQueries"

class App extends Component {
    render() {
        return (
            <div className="App">
                <Query query={GET_CATEGORY_Currency_LIST}>
                    {({loading, error, data}) => {
                        if (loading) return 'Loading...';
                        if (error) return `Error! ${JSON.stringify(error, null, 2)}`;
                        //modify data here before return
                        let category = data.categories[0].name
                        return (
                            //create Nav bar here using data.categories and data.currencies
                            <>
                                <Query query={GET_PRODUCTS_CATEGORY} variables={{category}}>
                                    {({loading, error, data}) => {
                                        if (loading) return 'Loading...';
                                        if (error) return `Error! ${JSON.stringify(error, null, 2)}`;
                                        return (
                                            //Add product List component  here
                                            <>
                                                <div className={"Body"}>Product</div>
                                                {
                                                    data.category.products.map(product => (
                                                        <div className={"Code"}>{product.name}</div>
                                                    ))
                                                }
                                            </>
                                        );
                                    }}
                                </Query>
                            </>
                        );
                    }}
                </Query>
            </div>
        );
    }
}
export default App;
