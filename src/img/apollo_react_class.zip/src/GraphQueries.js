import {gql} from "@apollo/client";

export const GET_PRODUCTS_CATEGORY = gql`
query products($category: String!) {
  category(input: { title: $category }) {
    name
    products {
      id
      name
      inStock
      gallery
      description
      brand
      prices {
        amount
        currency {
          label
        }
      }
    }
  }
}`;

export const GET_CATEGORY_Currency_LIST = gql`
query {
  categories {
    name
  }
  currencies {
    label
    symbol
  }
}`;

export const GET_PRODUCT = gql`
query product($id: String!) {
  product(id: $id) {
    id
    inStock
    description
    category
    gallery
    brand
    prices {
      currency {
        symbol
        label
      }
      amount
    }
    attributes {
      id
      name
      type
      items {
        id
        displayValue
      }
    }
  }
}

`;